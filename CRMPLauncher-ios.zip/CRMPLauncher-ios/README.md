# CRMP Launcher (iOS)

1. Впиши свои адреса в `CRMPLauncher/Core/Config.swift` (`configURL`) и выложи `server/config.example.json` как config.json на свой HTTPS-хостинг (свои IP:порт серверов).
2. Залей папку на GitHub, вкладка Actions -> Build IPA -> Run workflow.
3. Скачай артефакт CRMPLauncher-ipa (неподписанный .ipa) и поставь через AltStore / Sideloadly / TrollStore.
