import SwiftUI

struct Background: View {
    var body: some View {
        LinearGradient(colors: [Theme.bg, Theme.bgEnd], startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
    }
}

struct AppLogo: View {
    var size: CGFloat = 28

    private var parts: [String] {
        Config.appName.split(separator: " ", maxSplits: 1).map(String.init)
    }

    var body: some View {
        HStack(spacing: 8) {
            Text(parts.first ?? "").foregroundStyle(Theme.accent)
            if parts.count > 1 {
                Text(parts[1]).foregroundStyle(Theme.text)
            }
        }
        .font(.system(size: size, weight: .heavy))
    }
}

struct PrimaryButton: View {
    let title: String
    var icon: String? = nil
    var disabled = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                if let icon {
                    Image(systemName: icon)
                }
                Text(title).font(.headline.bold())
            }
            .foregroundStyle(Theme.text)
            .padding(.horizontal, 36)
            .frame(height: 52)
            .background(Capsule().fill(Theme.accentGradient))
            .shadow(color: Theme.accent.opacity(0.5), radius: 12)
            .opacity(disabled ? 0.5 : 1)
        }
        .disabled(disabled)
    }
}

struct PillTab: View {
    let title: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.bold())
                .foregroundStyle(Theme.text)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(selected ? AnyShapeStyle(Theme.accentGradient)
                                       : AnyShapeStyle(Color(hex: 0x222222)))
                )
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.accentLight, lineWidth: 1))
        }
    }
}

struct ServerCard: View {
    let server: ServerInfo
    let selected: Bool

    private var fill: Double {
        server.maxOnline > 0 ? min(1, Double(server.online) / Double(server.maxOnline)) : 0
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(server.name.uppercased())
                    .font(.headline.bold())
                    .foregroundStyle(Theme.text)
                Spacer()
                Text(server.isOnline ? "\(server.pingMs) ms" : "offline")
                    .font(.caption.bold())
                    .foregroundStyle(Theme.text)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(server.isOnline ? Theme.accent : Color.gray))
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.12))
                    Capsule()
                        .fill(selected ? Theme.accent : Color.white.opacity(0.4))
                        .frame(width: max(14, geo.size.width * fill))
                }
            }
            .frame(height: 14)

            HStack {
                Spacer()
                Text("\(server.online)").font(.title3.bold()).foregroundStyle(Theme.text)
                Text("/\(server.maxOnline)").font(.title3).foregroundStyle(Theme.muted)
                Spacer()
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 14).fill(
                LinearGradient(
                    colors: selected ? [Color(hex: 0x3A0A0A), Color(hex: 0x8A1414)]
                                     : [Color(hex: 0x2A2A2A), Color(hex: 0x4A4A4A)],
                    startPoint: .top, endPoint: .bottom))
        )
        .contentShape(RoundedRectangle(cornerRadius: 14))
    }
}
