import SwiftUI

/// Ключи настроек. Игровой клиент может читать их из UserDefaults.
enum Pref {
    static let carControl = "pref.carControl"
    static let joystick = "pref.joystick"
    static let camH = "pref.camH"
    static let camV = "pref.camV"
    static let aimH = "pref.aimH"
    static let aimV = "pref.aimV"
    static let backView = "pref.backView"
    static let vibro = "pref.vibro"
    static let effectsVol = "pref.effectsVol"
    static let voiceVol = "pref.voiceVol"
    static let showSpeakers = "pref.showSpeakers"
    static let voiceChat = "pref.voiceChat"
    static let keepMic = "pref.keepMic"
    static let uncensoredRadio = "pref.uncensoredRadio"
    static let blockAudio = "pref.blockAudio"
    static let resolution = "pref.resolution"
    static let effects = "pref.effects"
    static let water = "pref.water"
    static let shadows = "pref.shadows"
    static let reflections = "pref.reflections"
    static let drawDistance = "pref.drawDistance"
    static let vegetation = "pref.vegetation"
    static let maxFPS = "pref.maxFPS"
    static let ssaa = "pref.ssaa"

    static let all: [String] = [
        carControl, joystick, camH, camV, aimH, aimV, backView, vibro,
        effectsVol, voiceVol, showSpeakers, voiceChat, keepMic, uncensoredRadio, blockAudio,
        resolution, effects, water, shadows, reflections, drawDistance, vegetation, maxFPS, ssaa
    ]
}

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    var range: ClosedRange<Double> = 0.1...2.0
    var format = "%.1f"

    var body: some View {
        VStack(spacing: 4) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: format, value))
            }
            .foregroundStyle(Theme.text)
            Slider(value: $value, in: range).tint(Theme.accent)
        }
    }
}

struct ToggleRow: View {
    let title: String
    @Binding var isOn: Bool

    var body: some View {
        Toggle(title, isOn: $isOn)
            .tint(Theme.accent)
            .foregroundStyle(Theme.text)
    }
}

struct StepRow: View {
    let title: String
    let options: [String]
    @Binding var index: Int

    var body: some View {
        VStack(spacing: 4) {
            HStack {
                Text(title)
                Spacer()
                Text(options[min(max(index, 0), options.count - 1)])
            }
            .foregroundStyle(Theme.text)
            Slider(
                value: Binding(get: { Double(index) },
                               set: { index = Int($0.rounded()) }),
                in: 0...Double(options.count - 1),
                step: 1
            )
            .tint(Theme.accent)
        }
    }
}

struct SettingsView: View {
    let close: () -> Void

    enum Tab { case controls, sound, graphics }
    @State private var tab: Tab = .controls

    @AppStorage(Pref.carControl) private var carControl = 0
    @AppStorage(Pref.joystick) private var joystick = 1.0
    @AppStorage(Pref.camH) private var camH = 1.0
    @AppStorage(Pref.camV) private var camV = 1.0
    @AppStorage(Pref.aimH) private var aimH = 1.0
    @AppStorage(Pref.aimV) private var aimV = 1.0
    @AppStorage(Pref.backView) private var backView = true
    @AppStorage(Pref.vibro) private var vibro = true

    @AppStorage(Pref.effectsVol) private var effectsVol = 100.0
    @AppStorage(Pref.voiceVol) private var voiceVol = 100.0
    @AppStorage(Pref.showSpeakers) private var showSpeakers = true
    @AppStorage(Pref.voiceChat) private var voiceChat = true
    @AppStorage(Pref.keepMic) private var keepMic = true
    @AppStorage(Pref.uncensoredRadio) private var uncensoredRadio = false
    @AppStorage(Pref.blockAudio) private var blockAudio = false

    @AppStorage(Pref.resolution) private var resolution = 100.0
    @AppStorage(Pref.effects) private var effects = 1
    @AppStorage(Pref.water) private var water = 0
    @AppStorage(Pref.shadows) private var shadows = 0
    @AppStorage(Pref.reflections) private var reflections = 0
    @AppStorage(Pref.drawDistance) private var drawDistance = 1
    @AppStorage(Pref.vegetation) private var vegetation = 0
    @AppStorage(Pref.maxFPS) private var maxFPS = 60.0
    @AppStorage(Pref.ssaa) private var ssaa = false

    var body: some View {
        ZStack {
            Background()
            VStack(spacing: 0) {
                HStack(spacing: 28) {
                    tabButton("Управление", .controls)
                    tabButton("Звук", .sound)
                    tabButton("Настройки графики", .graphics)
                    Spacer()
                    Button(action: close) {
                        Image(systemName: "xmark")
                            .font(.title2.bold())
                            .foregroundStyle(Theme.text)
                    }
                }
                .padding(.horizontal, 28)
                .padding(.vertical, 16)

                Rectangle().fill(Color.white.opacity(0.4)).frame(height: 1)

                ScrollView {
                    VStack(spacing: 18) { tabContent }
                        .padding(24)
                }

                Button {
                    Pref.all.forEach { UserDefaults.standard.removeObject(forKey: $0) }
                } label: {
                    Text("Сбросить настройки")
                        .font(.subheadline)
                        .underline()
                        .foregroundStyle(Theme.text)
                }
                .padding(.vertical, 12)
            }
        }
    }

    private func tabButton(_ title: String, _ t: Tab) -> some View {
        Button { tab = t } label: {
            Text(title)
                .font(.headline.bold())
                .foregroundStyle(tab == t ? Theme.text : Theme.muted)
        }
    }

    @ViewBuilder
    private var tabContent: some View {
        switch tab {
        case .controls:
            HStack {
                Text("Способ управления авто").foregroundStyle(Theme.text)
                Spacer()
                Picker("", selection: $carControl) {
                    Text("Джойстик").tag(0)
                    Text("Кнопки").tag(1)
                }
                .pickerStyle(.menu)
                .tint(Theme.text)
            }
            SliderRow(title: "Чувствительность джойстика", value: $joystick)
            SliderRow(title: "Чувствительность обзора камеры по горизонтали", value: $camH)
            SliderRow(title: "Чувствительность обзора камеры по вертикали", value: $camV)
            SliderRow(title: "Чувствительность камеры при прицеливании по горизонтали", value: $aimH)
            SliderRow(title: "Чувствительность камеры при прицеливании по вертикали", value: $aimV)
            ToggleRow(title: "Включение вида назад", isOn: $backView)
            ToggleRow(title: "Включение вибро-отклика", isOn: $vibro)
        case .sound:
            SliderRow(title: "Громкость эффектов", value: $effectsVol, range: 0...100, format: "%.0f")
            SliderRow(title: "Общая громкость говорящих", value: $voiceVol, range: 0...100, format: "%.0f")
            ToggleRow(title: "Отображение говорящих", isOn: $showSpeakers)
            ToggleRow(title: "Включить войс чат", isOn: $voiceChat)
            ToggleRow(title: "Не отключать микрофон по времени", isOn: $keepMic)
            ToggleRow(title: "Радио без цензуры", isOn: $uncensoredRadio)
            ToggleRow(title: "Блокировка подключения к аудиопотокам", isOn: $blockAudio)
        case .graphics:
            SliderRow(title: "Разрешение", value: $resolution, range: 50...100, format: "%.0f")
            StepRow(title: "Качество эффектов",
                    options: ["Низкое", "Стандартное", "Высокое", "Ультра"], index: $effects)
            StepRow(title: "Качество воды",
                    options: ["Низкое", "Среднее", "Высокое", "Ультра"], index: $water)
            StepRow(title: "Качество теней",
                    options: ["Выключено", "Низкое", "Среднее", "Высокое"], index: $shadows)
            StepRow(title: "Качество отражений",
                    options: ["Выключено", "Низкое", "Среднее", "Высокое"], index: $reflections)
            StepRow(title: "Дальность прорисовки",
                    options: ["Низкая", "Стандартная", "Высокая", "Максимальная"], index: $drawDistance)
            StepRow(title: "Качество растительности",
                    options: ["Низкое", "Среднее", "Высокое"], index: $vegetation)
            SliderRow(title: "Максимальный FPS", value: $maxFPS, range: 30...120, format: "%.0f")
            ToggleRow(title: "SSAA", isOn: $ssaa)
        }
    }
}
