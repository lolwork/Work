import SwiftUI

struct ServerRow: View {
    let server: ServerInfo
    let selected: Bool

    private var pingColor: Color {
        guard server.isOnline else { return Theme.bad }
        if server.pingMs < 80 { return Theme.ok }
        if server.pingMs < 160 { return Theme.warn }
        return Theme.bad
    }

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(server.name)
                    .font(.headline)
                    .foregroundStyle(Theme.text)
                Text(server.hostname.isEmpty ? "\(server.host):\(server.port)" : server.hostname)
                    .font(.caption)
                    .foregroundStyle(Theme.muted)
                    .lineLimit(1)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(server.isOnline ? "\(server.online)/\(server.maxOnline)" : "—")
                    .font(.subheadline.bold())
                    .foregroundStyle(Theme.text)
                Text(server.isOnline ? "\(server.pingMs) ms" : "offline")
                    .font(.caption)
                    .foregroundStyle(pingColor)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(selected ? Theme.cardSelected : Theme.card)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(selected ? Theme.purple : Color.white.opacity(0.12),
                        lineWidth: selected ? 2 : 1)
        )
        .contentShape(RoundedRectangle(cornerRadius: 14))
    }
}
