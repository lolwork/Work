import SwiftUI

enum Theme {
    static let bg = Color(hex: 0x0B0612)
    static let bgEnd = Color(hex: 0x1E0F3A)
    static let card = Color(hex: 0x1A1228)
    static let cardSelected = Color(hex: 0x2A1850)
    static let purple = Color(hex: 0x8B5CF6)
    static let purpleDark = Color(hex: 0x5B21B6)
    static let text = Color(hex: 0xF3EEFF)
    static let muted = Color(hex: 0xA99CC4)
    static let ok = Color(hex: 0x4ADE80)
    static let warn = Color(hex: 0xFACC15)
    static let bad = Color(hex: 0xF87171)

    static func color(for kind: StatusKind) -> Color {
        switch kind {
        case .muted: return muted
        case .ok: return ok
        case .warn: return warn
        case .bad: return bad
        }
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: 1)
    }
}
