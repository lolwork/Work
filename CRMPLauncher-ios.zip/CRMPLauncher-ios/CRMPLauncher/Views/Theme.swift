import SwiftUI

enum Theme {
    static let bg = Color(hex: 0x0A0F1E)
    static let bgEnd = Color(hex: 0x2A1210)
    static let navy = Color(hex: 0x2B3A5C)
    static let panel = Color(hex: 0x262626)
    static let card = Color(hex: 0x1B2236)
    static let accent = Color(hex: 0xE5320D)
    static let accentLight = Color(hex: 0xF2540F)
    static let text = Color.white
    static let muted = Color(hex: 0x9AA3B8)
    static let ok = Color(hex: 0x4ADE80)
    static let warn = Color(hex: 0xFACC15)
    static let bad = Color(hex: 0xF87171)

    static let accentGradient = LinearGradient(
        colors: [Color(hex: 0xE5320D), Color(hex: 0xF2540F)],
        startPoint: .leading, endPoint: .trailing)

    static func color(for kind: StatusKind) -> Color {
        switch kind {
        case .muted: return muted
        case .ok: return ok
        case .warn: return warn
        case .bad: return bad
        }
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: 1)
    }
}
