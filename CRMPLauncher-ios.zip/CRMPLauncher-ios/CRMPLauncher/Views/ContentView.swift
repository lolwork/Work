import SwiftUI

enum AppScreen { case splash, main, servers, settings }

struct ContentView: View {
    @StateObject private var vm = LauncherViewModel()
    @State private var screen: AppScreen = .splash

    var body: some View {
        ZStack {
            switch screen {
            case .splash:
                SplashView()
            case .main:
                MainView(vm: vm,
                         openServers: { screen = .servers },
                         openSettings: { screen = .settings })
            case .servers:
                ServersView(vm: vm, back: { screen = .main })
            case .settings:
                SettingsView(close: { screen = .main })
            }
        }
        .animation(.easeInOut(duration: 0.2), value: screen)
        .preferredColorScheme(.dark)
        .statusBarHidden(true)
        .task { await vm.refresh() }
        .task {
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            screen = .main
        }
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            Background()
            VStack(spacing: 18) {
                AppLogo(size: 54)
                Text("Идёт загрузка…")
                    .font(.subheadline.italic())
                    .foregroundStyle(Theme.muted)
                ProgressView()
                    .progressViewStyle(.linear)
                    .tint(Theme.accent)
                    .frame(maxWidth: 420)
            }
            .padding(24)
        }
    }
}

struct MainView: View {
    @ObservedObject var vm: LauncherViewModel
    let openServers: () -> Void
    let openSettings: () -> Void
    @State private var showInfo = false

    var body: some View {
        ZStack {
            Background()
            VStack(spacing: 0) {
                HStack(alignment: .top, spacing: 10) {
                    TextField("", text: $vm.nick,
                              prompt: Text("Name_Surname").foregroundColor(Theme.muted))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .foregroundStyle(Theme.text)
                        .padding(.horizontal, 14)
                        .frame(width: 240, height: 48)
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.black.opacity(0.35)))
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.7), lineWidth: 1))

                    Button { showInfo = true } label: {
                        Image(systemName: "info")
                            .font(.title3.bold())
                            .foregroundStyle(Theme.text)
                            .frame(width: 48, height: 48)
                            .background(RoundedRectangle(cornerRadius: 10).fill(Theme.accent))
                    }

                    Spacer()

                    VStack(spacing: 10) {
                        social("paperplane.fill", Config.telegramURL)
                        social("bubble.left.and.bubble.right.fill", Config.discordURL)
                        social("person.2.fill", Config.vkURL)
                    }
                }

                Spacer()

                HStack(alignment: .bottom) {
                    Button(action: openSettings) {
                        HStack(spacing: 12) {
                            Image(systemName: "gearshape.fill").font(.title2)
                            Text("Настройки").font(.title3)
                        }
                        .foregroundStyle(Theme.muted)
                        .padding(.horizontal, 18)
                        .frame(height: 56)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.08)))
                    }
                    Spacer()
                    AppLogo(size: 28)
                    Spacer()
                    PrimaryButton(title: "ИГРАТЬ", icon: "play.fill", action: openServers)
                }
            }
            .padding(24)
        }
        .sheet(isPresented: $showInfo) {
            InfoSheet(text: vm.news, updateURL: vm.updateURL)
        }
    }

    @ViewBuilder
    private func social(_ icon: String, _ url: String) -> some View {
        if let u = URL(string: url) {
            Link(destination: u) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(Theme.text)
                    .frame(width: 52, height: 52)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.12)))
            }
        }
    }
}

struct InfoSheet: View {
    let text: String
    let updateURL: URL?

    var body: some View {
        ZStack {
            Background()
            VStack(alignment: .leading, spacing: 16) {
                Text("Новости").font(.title2.bold()).foregroundStyle(Theme.text)
                Text(text.isEmpty ? "Новостей пока нет." : text)
                    .foregroundStyle(Theme.muted)
                if let url = updateURL {
                    Link("Доступно обновление лаунчера", destination: url)
                        .foregroundStyle(Theme.warn)
                }
                Spacer()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(24)
        }
        .preferredColorScheme(.dark)
    }
}

struct ServersView: View {
    @ObservedObject var vm: LauncherViewModel
    let back: () -> Void
    @State private var showAll = false

    var body: some View {
        ZStack {
            Background()
            VStack(spacing: 14) {
                HStack(spacing: 14) {
                    Button(action: back) {
                        Image(systemName: "chevron.left")
                            .font(.title2.bold())
                            .foregroundStyle(Theme.text)
                    }
                    Text("Выбор сервера")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(Theme.text)
                    Spacer()
                    PillTab(title: "Мой сервер", selected: !showAll) { showAll = false }
                        .frame(width: 170)
                    PillTab(title: "Все сервера", selected: showAll) { showAll = true }
                        .frame(width: 170)
                }

                Rectangle().fill(Theme.accent).frame(height: 1)

                content

                Spacer(minLength: 0)

                VStack(spacing: 8) {
                    if vm.isBusy || vm.progress > 0 {
                        ProgressView(value: vm.progress)
                            .tint(Theme.accent)
                            .frame(maxWidth: 420)
                    }
                    Text(vm.status)
                        .font(.caption)
                        .foregroundStyle(Theme.color(for: vm.statusKind))
                    PrimaryButton(title: "Играть", disabled: vm.isBusy) {
                        Task { await vm.play() }
                    }
                }
            }
            .padding(24)
        }
    }

    @ViewBuilder
    private var content: some View {
        if showAll {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 260), spacing: 14)], spacing: 14) {
                    ForEach(vm.servers) { s in
                        ServerCard(server: s, selected: s.id == vm.selectedID)
                            .onTapGesture { vm.selectedID = s.id }
                    }
                }
            }
            .refreshable { await vm.refresh() }
        } else if let s = vm.selectedServer {
            ServerCard(server: s, selected: true)
                .frame(maxWidth: 420)
                .padding(.top, 8)
        } else {
            Text("Сервер не выбран").foregroundStyle(Theme.muted)
        }
    }
}
