import SwiftUI

struct ContentView: View {
    @StateObject private var vm = LauncherViewModel()

    var body: some View {
        ZStack {
            LinearGradient(colors: [Theme.bg, Theme.bgEnd],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 12) {
                header

                if !vm.news.isEmpty {
                    Text(vm.news)
                        .font(.footnote)
                        .foregroundStyle(Theme.muted)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(14)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.card))
                }

                if let url = vm.updateURL {
                    Link(destination: url) {
                        Text("Доступно обновление лаунчера")
                            .font(.subheadline)
                            .foregroundStyle(Theme.warn)
                            .frame(maxWidth: .infinity)
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 14).fill(Theme.card))
                    }
                }

                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(vm.servers) { server in
                            ServerRow(server: server, selected: server.id == vm.selectedID)
                                .onTapGesture { vm.selectedID = server.id }
                        }
                    }
                }
                .refreshable { await vm.refresh() }

                TextField("", text: $vm.nick,
                          prompt: Text("Ник (Name_Surname)").foregroundColor(Theme.muted))
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .foregroundStyle(Theme.text)
                    .padding(.horizontal, 14)
                    .frame(height: 48)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.08)))
                    .overlay(RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.white.opacity(0.25), lineWidth: 1))

                ProgressView(value: vm.progress)
                    .tint(Theme.purple)

                Text(vm.status)
                    .font(.caption)
                    .foregroundStyle(Theme.color(for: vm.statusKind))
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button {
                    Task { await vm.play() }
                } label: {
                    Text("ИГРАТЬ")
                        .font(.headline)
                        .foregroundStyle(Theme.text)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(
                            RoundedRectangle(cornerRadius: 14)
                                .fill(LinearGradient(colors: [Theme.purpleDark, Theme.purple],
                                                     startPoint: .leading, endPoint: .trailing))
                        )
                        .opacity(vm.isBusy ? 0.5 : 1)
                }
                .disabled(vm.isBusy)
            }
            .padding(20)
        }
        .preferredColorScheme(.dark)
        .task { await vm.refresh() }
    }

    private var header: some View {
        HStack {
            Text("CRMP LAUNCHER")
                .font(.title2.bold())
                .tracking(3)
                .foregroundStyle(Theme.text)
            Spacer()
            Button("Обновить") { Task { await vm.refresh() } }
                .font(.subheadline)
                .foregroundStyle(Theme.purple)
        }
    }
}
