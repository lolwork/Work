import Foundation
import Network

enum SampQueryError: Error {
    case resolveFailed, timeout, badResponse
}

/// Запрос 'i' по UDP — онлайн, максимум игроков, имя сервера, пинг.
enum SampQuery {

    static func query(_ server: ServerInfo, timeout: TimeInterval = 2.0) async throws -> ServerInfo {
        let ip = try await Task.detached { try resolveIPv4(server.host) }.value

        var request = Data("SAMP".utf8)
        request.append(contentsOf: ip)
        request.append(UInt8(server.port & 0xFF))
        request.append(UInt8((server.port >> 8) & 0xFF))
        request.append(UInt8(ascii: "i"))

        let ipString = ip.map(String.init).joined(separator: ".")
        let (data, ping) = try await exchange(host: ipString, port: server.port,
                                              request: request, timeout: timeout)
        return try parse(data, server: server, ping: ping)
    }

    // MARK: - Сеть

    private final class Once {
        private let lock = NSLock()
        private var done = false
        func run(_ block: () -> Void) {
            lock.lock(); defer { lock.unlock() }
            if done { return }
            done = true
            block()
        }
    }

    private static func exchange(host: String, port: Int, request: Data,
                                 timeout: TimeInterval) async throws -> (Data, Int) {
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(truncatingIfNeeded: port)) else {
            throw SampQueryError.badResponse
        }
        let conn = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .udp)
        let once = Once()

        return try await withCheckedThrowingContinuation { cont in
            var sentAt = DispatchTime.now()

            func finish(_ result: Result<(Data, Int), Error>) {
                once.run {
                    conn.cancel()
                    cont.resume(with: result)
                }
            }

            conn.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    sentAt = DispatchTime.now()
                    conn.send(content: request, completion: .contentProcessed { error in
                        if let error { finish(.failure(error)); return }
                        conn.receiveMessage { data, _, _, error in
                            if let error { finish(.failure(error)); return }
                            guard let data else { finish(.failure(SampQueryError.badResponse)); return }
                            let ns = DispatchTime.now().uptimeNanoseconds - sentAt.uptimeNanoseconds
                            finish(.success((data, Int(ns / 1_000_000))))
                        }
                    })
                case .failed(let error):
                    finish(.failure(error))
                default:
                    break
                }
            }

            conn.start(queue: .global())
            DispatchQueue.global().asyncAfter(deadline: .now() + timeout) {
                finish(.failure(SampQueryError.timeout))
            }
        }
    }

    /// Блокирующий резолв IPv4 (вызывать вне главного потока).
    private static func resolveIPv4(_ host: String) throws -> [UInt8] {
        var hints = addrinfo()
        hints.ai_family = AF_INET
        hints.ai_socktype = SOCK_DGRAM
        var result: UnsafeMutablePointer<addrinfo>?

        guard getaddrinfo(host, nil, &hints, &result) == 0, let first = result else {
            throw SampQueryError.resolveFailed
        }
        defer { freeaddrinfo(result) }

        guard let sa = first.pointee.ai_addr else { throw SampQueryError.resolveFailed }
        return sa.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { p in
            var addr = p.pointee.sin_addr.s_addr // уже в сетевом порядке байт
            return withUnsafeBytes(of: &addr) { Array($0) }
        }
    }

    // MARK: - Разбор ответа

    private static func parse(_ data: Data, server: ServerInfo, ping: Int) throws -> ServerInfo {
        let b = [UInt8](data)
        guard b.count >= 11 + 9, Array(b[0..<4]) == Array("SAMP".utf8) else {
            throw SampQueryError.badResponse
        }
        var o = 11
        o += 1 // флаг пароля
        let online = Int(b[o]) | Int(b[o + 1]) << 8; o += 2
        let maxOnline = Int(b[o]) | Int(b[o + 1]) << 8; o += 2
        let len = Int(b[o]) | Int(b[o + 1]) << 8 | Int(b[o + 2]) << 16 | Int(b[o + 3]) << 24; o += 4
        guard len >= 0, o + len <= b.count else { throw SampQueryError.badResponse }

        let name = String(data: Data(b[o..<(o + len)]), encoding: .windowsCP1251) ?? ""

        var s = server
        s.online = online
        s.maxOnline = maxOnline
        s.pingMs = ping
        s.hostname = name
        return s
    }
}
