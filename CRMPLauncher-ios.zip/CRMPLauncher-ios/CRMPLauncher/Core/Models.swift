import Foundation

struct ServerInfo: Identifiable, Hashable, Codable {
    var name: String
    var host: String
    var port: Int
    var online = 0
    var maxOnline = 0
    var pingMs = -1
    var hostname = ""

    var id: String { "\(host):\(port)" }
    var isOnline: Bool { pingMs >= 0 }

    // Из JSON приходят только эти три поля
    enum CodingKeys: String, CodingKey { case name, host, port }
}

struct GameFile: Decodable {
    let path: String
    let url: String
    let sha256: String
    let size: Int64

    enum CodingKeys: String, CodingKey { case path, url, sha256, size }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        path = try c.decode(String.self, forKey: .path)
        url = try c.decode(String.self, forKey: .url)
        sha256 = try c.decode(String.self, forKey: .sha256)
        size = try c.decodeIfPresent(Int64.self, forKey: .size) ?? 0
    }
}

struct RemoteConfig: Decodable {
    var launcherVersion: Int
    var updateURL: String
    var news: String
    var manifestURL: String
    var servers: [ServerInfo]

    static let fallback = RemoteConfig(
        launcherVersion: Config.launcherVersion,
        updateURL: "",
        news: "",
        manifestURL: "",
        servers: [
            ServerInfo(name: "Server #1", host: "127.0.0.1", port: 7777),
            ServerInfo(name: "Server #2", host: "127.0.0.1", port: 7778)
        ]
    )

    init(launcherVersion: Int, updateURL: String, news: String,
         manifestURL: String, servers: [ServerInfo]) {
        self.launcherVersion = launcherVersion
        self.updateURL = updateURL
        self.news = news
        self.manifestURL = manifestURL
        self.servers = servers
    }

    enum CodingKeys: String, CodingKey {
        case launcherVersion, updateUrl, news, manifestUrl, servers
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        launcherVersion = try c.decodeIfPresent(Int.self, forKey: .launcherVersion) ?? Config.launcherVersion
        updateURL = try c.decodeIfPresent(String.self, forKey: .updateUrl) ?? ""
        news = try c.decodeIfPresent(String.self, forKey: .news) ?? ""
        manifestURL = try c.decodeIfPresent(String.self, forKey: .manifestUrl) ?? ""
        let list = try c.decodeIfPresent([ServerInfo].self, forKey: .servers) ?? []
        servers = list.isEmpty ? RemoteConfig.fallback.servers : list
    }

    static func fetch() async throws -> RemoteConfig {
        let data = try await Http.getData(Config.configURL)
        return try JSONDecoder().decode(RemoteConfig.self, from: data)
    }
}

enum Http {
    static func getData(_ string: String) async throws -> Data {
        guard let url = URL(string: string), url.scheme == "https" else {
            throw URLError(.unsupportedURL)
        }
        var req = URLRequest(url: url)
        req.timeoutInterval = 10
        req.cachePolicy = .reloadIgnoringLocalCacheData
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        return data
    }
}
