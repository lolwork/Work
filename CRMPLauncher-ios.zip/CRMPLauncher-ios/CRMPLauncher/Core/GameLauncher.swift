import UIKit

/// iOS не позволяет запускать чужие приложения с произвольными extras,
/// поэтому данные передаются через URL-схему клиента.
enum GameLauncher {

    static func makeURL(nick: String, server: ServerInfo) -> URL? {
        var c = URLComponents()
        c.scheme = Config.gameURLScheme
        c.host = "connect"
        c.queryItems = [
            URLQueryItem(name: "nickname", value: nick),
            URLQueryItem(name: "host", value: server.host),
            URLQueryItem(name: "port", value: String(server.port))
        ]
        return c.url
    }

    @MainActor
    static func isInstalled() -> Bool {
        guard let url = URL(string: "\(Config.gameURLScheme)://") else { return false }
        return UIApplication.shared.canOpenURL(url)
    }

    @MainActor
    static func launch(nick: String, server: ServerInfo) async -> Bool {
        guard let url = makeURL(nick: nick, server: server) else { return false }
        return await UIApplication.shared.open(url, options: [:])
    }
}
