import Foundation
import CryptoKit

enum UpdaterError: LocalizedError {
    case badPath(String), badURL(String), badStatus(String), hashMismatch(String)

    var errorDescription: String? {
        switch self {
        case .badPath(let p): return "Недопустимый путь: \(p)"
        case .badURL(let u): return "Недопустимая ссылка: \(u)"
        case .badStatus(let p): return "Ошибка загрузки: \(p)"
        case .hashMismatch(let p): return "Хэш не совпал: \(p)"
        }
    }
}

final class Updater: @unchecked Sendable {
    let root: URL

    init() throws {
        let base = try FileManager.default.url(
            for: .applicationSupportDirectory, in: .userDomainMask,
            appropriateFor: nil, create: true)
        var dir = base.appendingPathComponent(Config.gameDirName, isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)

        // Файлы игры не нужно класть в iCloud-бэкап
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? dir.setResourceValues(values)

        root = dir.standardizedFileURL
    }

    func fetchManifest(_ url: String) async throws -> [GameFile] {
        let data = try await Http.getData(url)
        return try JSONDecoder().decode([GameFile].self, from: data)
    }

    /// Файлы, которых нет на диске или чей хэш не совпал с манифестом.
    func findOutdated(_ manifest: [GameFile]) async throws -> [GameFile] {
        try await Task.detached(priority: .utility) { [self] in
            try manifest.filter { file in
                try Task.checkCancellation()
                let target = try resolve(file.path)
                guard FileManager.default.fileExists(atPath: target.path) else { return true }
                return try Self.sha256(of: target).caseInsensitiveCompare(file.sha256) != .orderedSame
            }
        }.value
    }

    /// onProgress(0...1, имя файла). Прогресс считается по размерам файлов из манифеста.
    func download(_ files: [GameFile],
                  onProgress: @escaping @Sendable (Double, String) -> Void) async throws {
        let total = files.reduce(Int64(0)) { $0 + $1.size }
        var done: Int64 = 0
        let fm = FileManager.default

        for (index, file) in files.enumerated() {
            try Task.checkCancellation()
            onProgress(fraction(done, total, index, files.count), file.path)

            let target = try resolve(file.path)
            guard let url = URL(string: file.url), url.scheme == "https" else {
                throw UpdaterError.badURL(file.url)
            }

            let (tmp, response) = try await URLSession.shared.download(from: url)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                try? fm.removeItem(at: tmp)
                throw UpdaterError.badStatus(file.path)
            }

            let actual = try await Task.detached(priority: .utility) { try Self.sha256(of: tmp) }.value
            guard actual.caseInsensitiveCompare(file.sha256) == .orderedSame else {
                try? fm.removeItem(at: tmp)
                throw UpdaterError.hashMismatch(file.path)
            }

            try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
            try fm.moveItem(at: tmp, to: target)

            done += file.size
            onProgress(fraction(done, total, index + 1, files.count), file.path)
        }
        onProgress(1, "")
    }

    // MARK: - Вспомогательное

    private func fraction(_ done: Int64, _ total: Int64, _ index: Int, _ count: Int) -> Double {
        if total > 0 { return min(1, Double(done) / Double(total)) }
        return count > 0 ? Double(index) / Double(count) : 1
    }

    /// Защита от path traversal (../) в манифесте.
    private func resolve(_ relative: String) throws -> URL {
        let url = root.appendingPathComponent(relative).standardizedFileURL
        guard url.path.hasPrefix(root.path + "/") else { throw UpdaterError.badPath(relative) }
        return url
    }

    static func sha256(of url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = SHA256()
        while true {
            let chunk = try handle.read(upToCount: 1 << 20) ?? Data()
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
