import Foundation

enum Config {
    /// JSON с серверами, новостями и версией лаунчера (только HTTPS).
    static let configURL = "https://example.com/launcher/config.json"

    /// URL-схема игрового клиента: crmpclient://connect?nickname=...&host=...&port=...
    static let gameURLScheme = "crmpclient"

    /// Текущая версия лаунчера (сравнивается с launcherVersion из config.json).
    static let launcherVersion = 1

    /// Папка с файлами игры внутри Application Support.
    static let gameDirName = "game"
}
