import Foundation
import SwiftUI

enum StatusKind { case muted, ok, warn, bad }

@MainActor
final class LauncherViewModel: ObservableObject {

    @Published var servers: [ServerInfo] = RemoteConfig.fallback.servers
    @Published var selectedID: String?
    @Published var nick: String {
        didSet { UserDefaults.standard.set(nick, forKey: Self.nickKey) }
    }
    @Published var news = ""
    @Published var updateURL: URL?
    @Published var progress: Double = 0
    @Published var status = "Готов к запуску"
    @Published var statusKind: StatusKind = .muted
    @Published var isBusy = false

    private var config = RemoteConfig.fallback
    private var isRefreshing = false
    private static let nickKey = "nick"

    init() {
        nick = UserDefaults.standard.string(forKey: Self.nickKey) ?? ""
        selectedID = servers.first?.id
    }

    var selectedServer: ServerInfo? { servers.first { $0.id == selectedID } }

    // MARK: - Загрузка конфига и опрос серверов

    func refresh() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        do {
            config = try await RemoteConfig.fetch()
        } catch {
            config = .fallback
            setStatus("Не удалось загрузить конфиг, используется список по умолчанию", .warn)
        }

        news = config.news
        if config.launcherVersion > Config.launcherVersion,
           let url = URL(string: config.updateURL), url.scheme == "https" {
            updateURL = url
        } else {
            updateURL = nil
        }

        servers = config.servers
        if selectedID == nil || !servers.contains(where: { $0.id == selectedID }) {
            selectedID = servers.first?.id
        }

        let list = config.servers
        let result = await withTaskGroup(of: (Int, ServerInfo).self) { group in
            for (i, s) in list.enumerated() {
                group.addTask { (i, (try? await SampQuery.query(s)) ?? s) }
            }
            var out = list
            for await (i, s) in group { out[i] = s }
            return out
        }
        servers = result
    }

    // MARK: - Запуск

    func play() async {
        guard let server = selectedServer else {
            setStatus("Выберите сервер", .warn); return
        }
        let trimmed = nick.trimmingCharacters(in: .whitespaces)
        guard trimmed.range(of: "^[A-Za-z]{2,}_[A-Za-z]{2,}$", options: .regularExpression) != nil else {
            setStatus("Ник должен быть вида Name_Surname", .warn); return
        }
        guard GameLauncher.isInstalled() else {
            setStatus("Клиент игры не установлен", .bad); return
        }

        isBusy = true
        progress = 0
        defer { isBusy = false }

        do {
            if let _ = URL(string: config.manifestURL), !config.manifestURL.isEmpty {
                setStatus("Проверка файлов…", .muted)
                let updater = try Updater()
                let manifest = try await updater.fetchManifest(config.manifestURL)
                let outdated = try await updater.findOutdated(manifest)

                if !outdated.isEmpty {
                    try await updater.download(outdated) { [weak self] value, name in
                        Task { @MainActor in
                            self?.progress = value
                            self?.setStatus("Загрузка \(name) — \(Int(value * 100))%", .muted)
                        }
                    }
                }
            }

            setStatus("Запуск игры…", .ok)
            if await !GameLauncher.launch(nick: trimmed, server: server) {
                setStatus("Не удалось открыть клиент игры", .bad)
            }
        } catch {
            setStatus("Ошибка: \(error.localizedDescription)", .bad)
        }
    }

    private func setStatus(_ text: String, _ kind: StatusKind) {
        status = text
        statusKind = kind
    }
}
