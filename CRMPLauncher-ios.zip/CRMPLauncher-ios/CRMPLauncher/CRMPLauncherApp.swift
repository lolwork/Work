import SwiftUI

@main
struct CRMPLauncherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
